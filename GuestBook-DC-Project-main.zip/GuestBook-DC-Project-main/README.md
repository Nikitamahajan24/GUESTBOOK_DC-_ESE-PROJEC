open 3 terminal 
Run 
python manage.py runserver
python rpc_server.py
python rpc_server_2.py
